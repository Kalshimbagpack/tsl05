<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-4c16">
  <div class="u-clearfix u-sheet u-sheet-1">
    <p class="u-small-text u-text u-text-variant u-text-1">Beispieltext. Klicke, um das Textelement auszuwählen.</p>
  </div>
</footer>